MEMBRE(**idMembre**, nom, prenom, pseudonyme, motDePasse, email, niveau, estExclu)

THEME(**idTheme**, titre)

SUJET(**idSujet**, titre, dateAjout, estVerrouille, #idTheme, #idMembre)

CONTRIBUTION(**idContribution**, dateContribution, contenu, pieceJointe, estValidee, #idContribution_laquelle_on_répond, #idSujet, #idMembre)